//
//  CoreTextDisplayView.m
//  CoreTextDemo
//
//  Created by 花花 on 16/8/2.
//  Copyright © 2016年 花花. All rights reserved.
//

#import "CoreTextDisplayView.h"

@implementation CoreTextDisplayView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setTapEvent];
    }
    
    return self;
}

- (void)setTapEvent {
    
    self.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(jumpToLink:)];
    
    [self addGestureRecognizer:tap];
}

- (void)jumpToLink:(UITapGestureRecognizer *)tapRecognizer {
//    NSLog(@"jumpToLink");
    
    //获取点击在view上的坐标
    
    CGPoint point = [tapRecognizer locationInView:self];
    
    [self touchOfInViewWithPoint:point];
}

- (void)touchOfInViewWithPoint:(CGPoint)point {
    
    // 将点击的位置转换成字符串的偏移量，如果没有找到，则返回-1
    CFArrayRef linesArrayRef = CTFrameGetLines(self.frameRef);
    if (!linesArrayRef) {
        return;
    }
    
    CFIndex count = CFArrayGetCount(linesArrayRef);
    
    //获得每一行的origin坐标
    CGPoint originPoint[count];
    CTFrameGetLineOrigins(self.frameRef, CFRangeMake(0, 0), originPoint);
    
    // 翻转坐标系
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, self.bounds.size.height+20);
    
    transform = CGAffineTransformScale(transform, 1, -1);
    
    CFIndex index = -1;
    for (int i = 0; i < count; i++) {
        CGPoint linePoint = originPoint[i];
        CTLineRef lineRef = CFArrayGetValueAtIndex(linesArrayRef, i);
        
        // 获得每一行的CGRect信息
        CGFloat ascent = 0.0f;
        CGFloat descent = 0.0f;
        CGFloat leading = 0.0f;
        CGFloat width = (CGFloat)CTLineGetTypographicBounds(lineRef, &ascent, &descent, &leading);
        CGFloat height = ascent + descent;
        
        //点击
        CGRect flippedRect = CGRectMake(linePoint.x, linePoint.y - descent, width, height);
        
        CGRect rect = CGRectApplyAffineTransform(flippedRect, transform);
        
        if (CGRectContainsPoint(rect, point)) {
            // 将点击的坐标转换成相对于当前行的坐标
            CGPoint relativePoint = CGPointMake(point.x-CGRectGetMinX(rect),
                                                point.y-CGRectGetMinY(rect));
            // 获得当前点击坐标对应的字符串偏移
            index = CTLineGetStringIndexForPosition(lineRef, relativePoint);
        }
        
    }
    
    if (NSLocationInRange(index, self.linkRange)) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.baidu.com"]];
        
        
//        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"哈哈" message:@"这是链接" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
//        [alert show];
    }
}

- (void)drawRect:(CGRect)rect {
    
    NSMutableAttributedString *attribute = [[NSMutableAttributedString alloc]init];
    
    [attribute appendAttributedString:[self configFontWithCon:self.content]];
    
    NSUInteger startLocation = attribute.length;
    
    [attribute appendAttributedString:[self configFontWithCon:self.linkContent]];
    
    
    
    
    NSUInteger length = attribute.length - startLocation;
    
    self.linkRange = NSMakeRange(startLocation, length+1);
    [self createCTFrameSetterByContent:attribute];
}

#pragma mark -- 设置文字段落，字号
- (NSMutableAttributedString *)configFontWithCon:(NSString *)content {
    
    NSMutableDictionary *mDic_fontInfo = [NSMutableDictionary dictionary];
    
    CGFloat fontSize = 14;
    CTFontRef fontRef = CTFontCreateWithName((CFStringRef)@"ArialMT", fontSize, NULL);
    
    CGFloat lineSpace = 8.0f;
    const CFIndex kNumberOfSetting = 3;
    CTParagraphStyleSetting theSetting[kNumberOfSetting] = {
        {
            kCTParagraphStyleSpecifierLineSpacingAdjustment,sizeof(CGFloat),&lineSpace
        },
        {
            kCTParagraphStyleSpecifierMaximumLineHeight,sizeof(CGFloat),&lineSpace
        },
        {
            kCTParagraphStyleSpecifierMinimumLineHeight,sizeof(CGFloat),&lineSpace
        }
    };
    
    CTParagraphStyleRef paragraphStyleRef = CTParagraphStyleCreate(theSetting, kNumberOfSetting);
    
    UIColor *color;
    
    if ([content isEqualToString:self.linkContent]) {
        color = [UIColor blueColor];
    }else{
        color = [UIColor redColor];
    }
    
    
    mDic_fontInfo[(id)kCTForegroundColorAttributeName] = (id)(color.CGColor);
    mDic_fontInfo[(id)kCTFontAttributeName] = (__bridge id _Nullable)(fontRef);
    mDic_fontInfo[(id)kCTParagraphStyleAttributeName] = (__bridge id)paragraphStyleRef;
    
    CFRelease(fontRef);
    CFRelease(paragraphStyleRef);
    
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc]initWithString:content attributes:mDic_fontInfo];
//    [attributeString addAttribute:(id)kCTForegroundColorAttributeName value:[UIColor blueColor] range:NSMakeRange(content.length-2, 2)];
    
    
    return attributeString;
    
}

- (void)createCTFrameSetterByContent:(NSMutableAttributedString *)content {
    //CFAttributedStringRef
    CTFramesetterRef frameSetterRef = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)content);
    
    //创建路径
    
    CGMutablePathRef pathRef = CGPathCreateMutable();
    
    CGPathAddRect(pathRef, NULL, CGRectMake(10, 0, self.bounds.size.width-20, self.bounds.size.height));
    
    CTFrameRef frameRef = CTFramesetterCreateFrame(frameSetterRef, CFRangeMake(0, 0), pathRef, NULL);
    
    self.frameRef = frameRef;
    CFRelease(pathRef);
    CFRelease(frameSetterRef);
    
    //绘制当前view
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    
    //压栈，压入图形状态栈中.每个图形上下文维护一个图形状态栈，并不是所有的当前绘画环境的图形状态的元素都被保存。图形状态中不考虑当前路径，所以不保存
    //保存现在得上下文图形状态。不管后续对context上绘制什么都不会影响真正得屏幕。
    
    CGContextSaveGState(context);
    
    //x，y轴方向移动
    CGContextTranslateCTM(context, 0, self.bounds.size.height+20);
    
    //缩放x，y轴方向缩放，－1.0为反向1.0倍,坐标系转换,沿x轴翻转180度
    CGContextScaleCTM(context, 1, -1);
    
    CTFrameDraw(frameRef, context);
    
    
//    CFRelease(frameRef);
}

@end
