//
//  ViewController.m
//  CoreTextDemo
//
//  Created by 花花 on 16/8/1.
//  Copyright © 2016年 花花. All rights reserved.
//

#import "ViewController.h"
#import "CoreTextDisplayView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    self.view.backgroundColor = [UIColor whiteColor];
    
//    NSMutableAttributedString *attribute = [[NSMutableAttributedString alloc]initWithString:@"这是一个链接"];
    
//    CoreTextView *ctView = [[CoreTextView alloc]initCoreTextViewByCon:@"这是一个链接" height:20];
//    ctView.backgroundColor = [UIColor redColor];
//    [self.view addSubview:ctView];
    
    CoreTextDisplayView *ctdView = [[CoreTextDisplayView alloc]initWithFrame:CGRectMake(10, 64, self.view.frame.size.width-20, 100)];
    ctdView.content = @"这是一个";
    ctdView.linkContent = @"链接";
    ctdView.height = 100.0;
    ctdView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:ctdView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
