//
//  CoreTextDisplayView.h
//  CoreTextDemo
//
//  Created by 花花 on 16/8/2.
//  Copyright © 2016年 花花. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

@interface CoreTextDisplayView : UIView

@property (copy, nonatomic) NSString *content;
@property (copy, nonatomic) NSString *linkContent;//链接内容
@property (assign,nonatomic) CGFloat height;
@property (assign,nonatomic) CTFrameRef frameRef;
@property (assign,nonatomic) NSRange linkRange;//链接位置

@end
